function [indexSep] = Thwaites(U,S)
%Thwaites returns the index of the separation location for an inputted
%2D-geometry, using the Thwaites' separation methods

%Create Arc Length
X = [0];
for i = 2:numel(S)
    X = [X; X(i-1)+(S(i-1)/2)+(S(i)/2)];
end

I = zeros(numel(U)-1,1);
dudx = zeros(numel(U)-1,1);
for i = 2:length(U)-1
    I(i-1) = trapz(X(1:i),U(1:i).^5);
    %dudx(i) = diff(U(i:i+1))/diff(X(i:i+1));
    range = i-1:i+1;
    x_ = X(range);
    xbar = X(i);
    k = 1;
    [ c ] = mkfdstencil( x_ , xbar , k );
    dudx(i-1) = U(range)'*c;
end

k = abs(0.09 + (0.45./U(2:end).^6).*(dudx).*I);
[~,indexSep] = min(k);
end