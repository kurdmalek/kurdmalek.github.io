%% Selig S1223 Coordinates

X = [1
0.993582
0.984237
0.973452
0.960621
0.945173
0.926643
0.90488
0.880167
0.853151
0.824589
0.79513
0.765239
0.735204
0.705148
0.67507
0.644888
0.614467
0.583656
0.552304
0.520314
0.487697
0.454605
0.421337
0.388325
0.356059
0.325061
0.295869
0.268821
0.243816
0.220493
0.198517
0.177661
0.157772
0.138774
0.120658
0.103478
0.087347
0.07246
0.059065
0.047376
0.037469
0.029259
0.022548
0.017103
0.012701
0.009153
0.006314
0.004076
0.002365
0.001128
0.000338
-0.000008
0.00014
0.00104
0.003093
0.006271
0.010197
0.014706
0.019836
0.025728
0.032603
0.040784
0.050745
0.06316
0.078892
0.098681
0.122421
0.149036
0.177612
0.207911
0.239707
0.2725
0.305752
0.33893
0.371726
0.404038
0.435847
0.467163
0.498031
0.528494
0.558616
0.588443
0.618027
0.647402
0.676616
0.705687
0.734636
0.763438
0.792049
0.82034
0.848075
0.874835
0.900011
0.922918
0.943064
0.960352
0.975001
0.987341
1];
Y = [0
0.005174
0.012721
0.019959
0.026718
0.033431
0.040426
0.047739
0.055249
0.062781
0.07017
0.077285
0.08403
0.090329
0.096131
0.10141
0.106168
0.110429
0.114241
0.117672
0.120811
0.12375
0.126565
0.12929
0.131899
0.134296
0.136339
0.137848
0.138607
0.138418
0.137168
0.134818
0.131353
0.126772
0.121094
0.114364
0.106654
0.098106
0.088966
0.079596
0.070398
0.061702
0.053661
0.046281
0.039506
0.033277
0.027538
0.022235
0.017315
0.012727
0.008432
0.004397
0.000603
-0.003015
-0.006532
-0.009594
-0.011793
-0.013209
-0.01413
-0.014738
-0.015128
-0.01534
-0.015363
-0.015157
-0.014648
-0.013726
-0.012263
-0.010129
-0.007205
-0.003422
0.001142
0.006251
0.011665
0.017205
0.022704
0.02803
0.033089
0.037798
0.042089
0.045901
0.049183
0.051898
0.054011
0.055499
0.056339
0.056516
0.056018
0.054839
0.052976
0.050432
0.047218
0.04337
0.038946
0.03406
0.028856
0.023463
0.017954
0.012374
0.006802
0];

X = flip(X);
Y = flip(Y);

%Plotting airfoil to verify shape
figure
comet(X,Y)
%Desired angles of attack
U = 10; %Rotor-tip velocity
rho = 0.016; %Free-stream density (Mars) [kg/m cu]



%% Del. 1.2 (Cl = 2 @ alpha = 5�)

alpha = deg2rad(5);
[CP,Sj,x,y,vt,theta]=VPM(X,Y,alpha,U);
Cli = -CP'.*Sj.*sin(theta+(pi/2));
Cl = sum(Cli)


%% Calculations

close all

alpha = 3:1:10;
alpha = deg2rad(alpha);
angleLift_drag = [];

for i = 1:length(alpha)
     [CP,Sj,x,y,vt,theta]=VPM(X,Y,alpha(i),U);
     %Calculating CP-based Values
     Cli = (-CP.*Sj'.*sin(theta'+(pi/2)))';
     Cdi = (-CP.*Sj'.*cos(theta'+(pi/2)))';
     Cl = sum(Cli);
     Cd = sum(Cdi);
     A = [cos(alpha(i)) sin(alpha(i));-sin(alpha(i)) cos(alpha(i))]*[Cd;Cl];
     Fd = A(1)*(0.5*rho*(U^2));
     Fl = A(2)*(0.5*rho*(U^2));
     %Separation
     absV = abs(vt); 
     [m,stag_index] = min(absV);
     Sj_upper = Sj(stag_index:end);
     Sj_lower = Sj(stag_index:-1:1);
     Vt_upper = vt(stag_index:end);
     Vt_lower = vt(stag_index:-1:1);
     CP_upper = CP(stag_index:end);
     CP_lower = CP(stag_index:-1:1);
    %Thwaities
     sepTop = Thwaites(Vt_upper,Sj_upper);
     sepBot = Thwaites(Vt_lower,Sj_lower);     
     topPoint = stag_index+sepTop-1;
     botPoint = stag_index-sepBot+1;
     angleLift_drag = [angleLift_drag; alpha(i)*180/pi, Cl, -Cd, topPoint, botPoint];   
     %angleLift_drag = [angleLift_drag; alpha(i)*180/pi, Cl, -Cd, sepTop, sepBot];        
     if(mod(alpha,8*pi/180)==0)
        plot(x,CP);
        %disp(x(botPoint));
     end
end

%% CL v. Alpha

figure(3);
plot(angleLift_drag(:,1),angleLift_drag(:,2),'-o');
hold on
title('Coefficient of Lift v. Angle of Attack for Selig S1223 Airfoil');
xlabel('Angle of Attack (Degrees)');
ylabel('Coefficient of Lift');

%% Separation Plot @ AoA 5�

figure(4);


plot(X,Y); %%Change for airfoil
hold on
xSepT = x(angleLift_drag(3,4));
ySepT = y(angleLift_drag(3,4));
xSepB = x(angleLift_drag(3,5));
ySepB = y(angleLift_drag(3,5));
plot(xSepT,ySepT,'*');
plot(xSepB,ySepB,'*');
title(['Separation Points at 5� Angle of Attack'])
legend('Airfoil (Selig S1223)','Separation Point 1','Separation Point 2');
hold off


%%
% figure(4);
% for i = 1:length(alpha)
%     subplot(2,4,i);
%     plot(X,Y); %%Change for airfoil
%     hold on
%     xSepT(i) = x(angleLift_drag(i,4));
%     ySepT(i) = y(angleLift_drag(i,4));
%     xSepB(i) = x(angleLift_drag(i,5));
%     ySepB(i) = y(angleLift_drag(i,5));
%     plot(xSepT(i),ySepT(i),'*');
%     plot(xSepB(i),ySepB(i),'*');
%     title(['Separation Points at ',num2str(angleLift_drag(i,1)),' Angle of Attack'])
%     legend('Airfoil (Selig S1223)','Separation Point 1','Separation Point 2');
% end



%% Stall E423

%Want to plot angle versus chord distance where separation point occurs
sepTop = x(angleLift_drag(:,4));
sepBot = x(angleLift_drag(:,5));
angle = angleLift_drag(:,1);
figure(9)
hold on
plot(angle,sepTop,'-x');
plot(angle,sepBot,'-x');
title('Stall Angle Graph');
xlabel('Angle of Attack');
ylabel('Chord Distance of Separation');
legend('Top Surface Separation', 'Bottom Surface Separation')
