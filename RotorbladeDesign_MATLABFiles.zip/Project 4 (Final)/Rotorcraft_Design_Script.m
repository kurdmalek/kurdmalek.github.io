%% E423 Coordinates

X = [1
0.99655
0.98706
0.97304
0.9553
0.93358
0.90734
0.87671
0.84221
0.80436
0.76373
0.7209
0.67644
0.63092
0.58491
0.53893
0.49347
0.4487
0.40464
0.36149
0.31947
0.27885
0.23987
0.20286
0.16816
0.13611
0.107
0.08106
0.05852
0.03953
0.02421
0.01262
0.00481
0.00071
0.00002
0.00033
0.00071
0.00125
0.00157
0.00194
0.00237
0.00288
0.00348
0.00415
0.00571
0.00751
0.01065
0.01365
0.02892
0.04947
0.07533
0.1067
0.14385
0.18727
0.23688
0.29196
0.35163
0.41449
0.47867
0.54275
0.60579
0.6669
0.72503
0.77912
0.82836
0.87219
0.91012
0.94179
0.96692
0.98519
0.99629
1];
Y = [0
0.00159
0.0065
0.01434
0.02381
0.03376
0.044
0.05481
0.0662
0.07803
0.0901
0.10215
0.11391
0.12506
0.13524
0.1441
0.15116
0.15593
0.15828
0.15824
0.1559
0.15138
0.14485
0.13657
0.12676
0.11562
0.10337
0.09023
0.07646
0.06232
0.04812
0.03419
0.02093
0.00879
0.00088
-0.00192
-0.00362
-0.00518
-0.0059
-0.00656
-0.00717
-0.00771
-0.00823
-0.00874
-0.00969
-0.01057
-0.01177
-0.01266
-0.01485
-0.01482
-0.01236
-0.0074
-0.00002
0.00922
0.01913
0.02865
0.03687
0.04283
0.04626
0.0476
0.04715
0.04501
0.04126
0.03625
0.0305
0.02444
0.01844
0.01286
0.00794
0.0039
0.00106
0];

X = flip(X);
Y = flip(Y);

%Plotting airfoil to verify shape
figure
comet(X,Y)


%% Mars

T = 233; %[K]
rho = 0.016; %[kg/cu m]
P = 700; %[Pa]
g = 3.71; %[m/s^2]
R = 189; %[J/kg*K]
v = 10; %[cm^2/s]
gamma = 1.33; %Mars atm specific heat ratio
a = sqrt(gamma*R*T); %Speed of Sound Mars
%% Fixed Parameters

m = 1; %[kg]
T = m*g; %[N]
sigma = 0.1; 
Mtip = 0.5;
alpha = 5; %[�]
Ad = 1.5; %[m^2]
r_ratio = 0.25;
r_tip = sqrt(Ad/pi); %[m]
r_root = r_tip*r_ratio; %[m]
d = 2*r_tip; %[m]
Nb = 3; %number of blades
Vr_tip = Mtip*a; %tip relative velocity [m/s]
Vh = sqrt(T/(2*rho*Ad)); %hover velocity [m/s]
omega = 1/r_tip*sqrt(Vr_tip^2 - Vh^2); %rotor angular velocity [rad/s]

N = 50; %blade mesh discretization
t = (T/Nb)/N; %sectional thrust [N/m]
db = 0.75*r_tip/N; %blade length discretization

%% Radially-determined Parameters

syms cr

c = []; %chord-variation
Vr = []; %relative velocity
Beta = []; %propeller twist angle
CT =[]; %section thrust coefficient
CN = []; %section normal coefficient
CFyi = []; %section vertical force
CFxi = []; %section horizontal force
r = linspace(r_root,r_tip,N); %defining integration step size from root-to-tip radius

[CP,Sj,x,y,vt,theta] = VPM(X,Y,alpha,Vr_tip);

for i = 1:length(r)
    Vr(i) = sqrt((omega*r(i))^2+Vh^2);
    Beta(i) = atan2(Vh,(omega*r(i))); %sectional twist angle
    %[CP,Sj,x,y,vt,theta] = VPM(X,Y,alpha,Vr(i));
    CFyi = [CFyi;-CP.*Sj'.*sin(theta'+(pi/2))]; %lift twisting moment contribution
    CFxi = [CFyi;-CP.*Sj'.*cos(theta'+(pi/2))]; 
    CFy = sum(CFyi);
    CFx = sum(CFxi);
    A = [cos(alpha) sin(alpha);-sin(alpha) cos(alpha)]*[CFx;CFy];
    CD = A(1);
    CL = A(2);
    B = [cos(Beta(i)) sin(Beta(i)); -sin(Beta(i)) cos(Beta(i))]*[CD;CL];
    CN(i) = B(1); %section normal contribution
    CT(i) = B(2); %section thrust contribution
    eqn = t/(0.5*rho*Vr(i)^2*db*cr) == CT(i);
    c(i) = double(solve(eqn,cr)); %sectional chord variation 
end

%% Plot Blade Shape

xs = [];
ys = [];
Xrot = [];
Yrot = [];
Z = [];
for i = 1:length(r)
    [~,index] = min(abs(X-0.25));
    xs = (X.*c(i))-0.25*c(i);
    ys = (Y.*c(i))-Y(index); 
    %xs = (X.*c(i));
    %ys = (Y.*c(i)); 
    %scaled airfoil by sectional chord, shifted to be centered @ X_Cl
    Xrot = [Xrot;cos(Beta(i)).*xs'+sin(Beta(i)).*ys'];
    Yrot = [Yrot;-sin(Beta(i)).*xs'+cos(Beta(i)).*ys'];
    Z = [Z; r(i)*ones(1,length(Xrot))];
end

surf(Xrot,Yrot,Z)
title('Single Rotorcraft Blade: Eppler 423 Airfoil')

