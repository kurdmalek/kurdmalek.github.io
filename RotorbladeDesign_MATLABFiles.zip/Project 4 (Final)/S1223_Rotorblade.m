%% S1223 Coordinates

X = [1
0.993582
0.984237
0.973452
0.960621
0.945173
0.926643
0.90488
0.880167
0.853151
0.824589
0.79513
0.765239
0.735204
0.705148
0.67507
0.644888
0.614467
0.583656
0.552304
0.520314
0.487697
0.454605
0.421337
0.388325
0.356059
0.325061
0.295869
0.268821
0.243816
0.220493
0.198517
0.177661
0.157772
0.138774
0.120658
0.103478
0.087347
0.07246
0.059065
0.047376
0.037469
0.029259
0.022548
0.017103
0.012701
0.009153
0.006314
0.004076
0.002365
0.001128
0.000338
-0.000008
0.00014
0.00104
0.003093
0.006271
0.010197
0.014706
0.019836
0.025728
0.032603
0.040784
0.050745
0.06316
0.078892
0.098681
0.122421
0.149036
0.177612
0.207911
0.239707
0.2725
0.305752
0.33893
0.371726
0.404038
0.435847
0.467163
0.498031
0.528494
0.558616
0.588443
0.618027
0.647402
0.676616
0.705687
0.734636
0.763438
0.792049
0.82034
0.848075
0.874835
0.900011
0.922918
0.943064
0.960352
0.975001
0.987341
1];
Y = [0
0.005174
0.012721
0.019959
0.026718
0.033431
0.040426
0.047739
0.055249
0.062781
0.07017
0.077285
0.08403
0.090329
0.096131
0.10141
0.106168
0.110429
0.114241
0.117672
0.120811
0.12375
0.126565
0.12929
0.131899
0.134296
0.136339
0.137848
0.138607
0.138418
0.137168
0.134818
0.131353
0.126772
0.121094
0.114364
0.106654
0.098106
0.088966
0.079596
0.070398
0.061702
0.053661
0.046281
0.039506
0.033277
0.027538
0.022235
0.017315
0.012727
0.008432
0.004397
0.000603
-0.003015
-0.006532
-0.009594
-0.011793
-0.013209
-0.01413
-0.014738
-0.015128
-0.01534
-0.015363
-0.015157
-0.014648
-0.013726
-0.012263
-0.010129
-0.007205
-0.003422
0.001142
0.006251
0.011665
0.017205
0.022704
0.02803
0.033089
0.037798
0.042089
0.045901
0.049183
0.051898
0.054011
0.055499
0.056339
0.056516
0.056018
0.054839
0.052976
0.050432
0.047218
0.04337
0.038946
0.03406
0.028856
0.023463
0.017954
0.012374
0.006802
0];

X = flip(X);
Y = flip(Y);

%Plotting airfoil to verify shape
figure
comet(X,Y)


%% Mars

T = 233; %[K]
rho = 0.016; %[kg/cu m]
P = 700; %[Pa]
g = 3.71; %[m/s^2]
R = 189; %[J/kg*K]
v = 0.001 ; %[m^2/s] Kinematic viscosity
gamma = 1.33; %Mars atm specific heat ratio
a = sqrt(gamma*R*T); %Speed of Sound Mars
%% Fixed Parameters

m = 1; %[kg]
T = m*g; %[N]
sigma = 0.1; 
Mtip = 0.5;
alpha = 5; %[�]
Ad = 1.5; %[m^2]
r_ratio = 0.25;
r_tip = sqrt(Ad/pi); %[m]
r_root = r_tip*r_ratio; %[m]
d = 2*r_tip; %[m]
Nb = 3; %number of blades
Vr_tip = Mtip*a; %tip relative velocity [m/s]
Vh = sqrt(T/(2*rho*Ad)); %hover velocity [m/s]
omega = 1/r_tip*sqrt(Vr_tip^2 - Vh^2); %rotor angular velocity [rad/s]

N = 100; %blade mesh discretization
t = (T/Nb)/N; %sectional thrust [N/m]
db = 0.75*r_tip/N; %blade length discretization

%% Radially-determined Parameters

syms cr

c = []; %chord-variation
Vr = []; %relative velocity
Beta = []; %propeller twist angle
CT =[]; %section thrust coefficient
CN = []; %section normal coefficient
CFyi = []; %section vertical force
CFxi = []; %section horizontal force
CFy = [];
CFx = [];
r = linspace(r_root,r_tip,N); %defining integration step size from root-to-tip radius

[CP,Sj,x,y,vt,theta] = VPM(X,Y,alpha,Vr_tip);

for i = 1:length(r)
    Vr(i) = sqrt((omega*r(i))^2+Vh^2);
    Beta(i) = atan2(Vh,(omega*r(i))); %sectional twist angle
    CFyi = [CFyi;(CP.*Sj'.*sin(theta'+(pi/2)))']; %lift twisting moment contribution
    CFxi = [CFxi;(CP.*Sj'.*cos(theta'+(pi/2)))']; 
    CFy(i) = sum(CFyi(i,:));
    CFx(i) = sum(CFxi(i,:));
    A = [cos(alpha) sin(alpha);-sin(alpha) cos(alpha)]*[CFx(i);CFy(i)];
    CD = A(1);
    CL = A(2);
    B = [cos(Beta(i)) sin(Beta(i)); -sin(Beta(i)) cos(Beta(i))]*[CD;CL];
    CN(i) = B(1); %section normal contribution
    CT(i) = B(2); %section thrust contribution
    %eqn = t/(0.5*rho*Vr(i)^2*db*cr) == CT(i);
    eqn = t/(0.5*rho*Vr(i)^2*db*cr) == CT(i);
    c(i) = abs(double(solve(eqn,cr))); %sectional chord variation 
end

%% Viscous Drag

Re = []; %Reynold's number
cf = []; %section Viscuous Drag
tau = []; %section torque
for i = 1:length(r)
    Re(i) = Vr(i)*c(i)/v;
    cf(i) = 2*(0.664*(Re(i)^(-0.5))); %section viscous drag coefficient
    tau(i) = cf(i)*(0.5*rho*Vr(i)^2)*db*c(i)*r(i);
end

Tau = sum(tau); %total viscous drag torque of the blade [N*m]

%% Bending and Twisting

Cm_t = []; %Coefficient of thrust bending moment
Cmy_t = []; %Coefficient of thrust twisting moment

for i = 1:length(r)
    Cm_t(i) = CT(i)*r(i);
    Cmy_t(i) = -sum((c(i).*(x-0.25)).*CFyi(i,:)*(0.5*rho*Vr(i)^2)*db*c(i));
end

%% Required Deliverables

%chord variation
figure
plot(r,c)   
xlabel('Rotor Radius (m)')
ylabel('Radial Chord Variaton (m)')
title('Sectional Chord Variation')

%twist variation
figure
plot(r,rad2deg(Beta))
xlabel('Rotor Radius (m)')
ylabel('Blade Twist Angle (�)')
title('Sectional Blade Twist')

%Viscuous Drag Coefficient & Total Visc. Drag Torque
figure
plot(r,cf)
xlabel('Rotor Radius (m)')
ylabel('Coefficient of Viscuous Drag')
title('Sectional Viscuous Drag Coefficient')
legend(strcat('Associated Total Visc. Drag Torque = ', num2str(Tau)))

%Section Thrust Coefficients
figure
plot(r,CT)
xlabel('Rotor Radius (m)')
ylabel('Thrust Force Coefficients')
title('Sectional Thrust Force Distribution')

%Section Normal Coefficients
figure
plot(r,CN)
xlabel('Rotor Radius (m)')
ylabel('Normal Force Coefficient')
title('Sectional Normal Force Distribution')

%Bending Moment Distribution
figure
plot(r,Cm_t)
xlabel('Rotor Radius (m)')
ylabel('Coefficient of Bending Moment')
title('Sectional Bending Moment Distribution')

%Twisting Moment Distribution
figure
plot(r,Cmy_t)
xlabel('Rotor Radius (m)')
ylabel('Coefficient of Twist Moment')
title('Sectional Twist Moment Distribution')

hold off


%% Plot Blade Shape

xs = [];
ys = [];
Xrot = [];
Yrot = [];
Z = [];
for i = 1:length(r)
    [~,index] = min(abs(X-0.25));
    xs = (X.*c(i))-0.25*c(i);
    ys = (Y.*c(i))-Y(index); 
    %xs = (X.*c(i));
    %ys = (Y.*c(i)); 
    %scaled airfoil by sectional chord, shifted to be centered @ X_Cl
    Xrot = [Xrot;cos(Beta(i)).*xs'+sin(Beta(i)).*ys'];
    Yrot = [Yrot;-sin(Beta(i)).*xs'+cos(Beta(i)).*ys'];
    Z = [Z; r(i)*ones(1,length(Xrot))];
end 

figure
surf(Xrot,Yrot,Z)
title('Single Rotorcraft Blade: Selig S1223 Airfoil')
view(0,0)  % XY
pause
view(90,90)   % XZ
pause
view(-90,0)


