function [ c ] = mkfdstencil( x , xbar , k )

n=length(x);
f = zeros(n,1);
V = zeros(n,n);

for i=1:n
    for j=1:n
        V(i,j) = (1/(factorial( i-1 )))*( x(j) - xbar )^(i-1);
    end
    if (i-1) == k ; f(i) =  1; end
end
c = V\f;
end

