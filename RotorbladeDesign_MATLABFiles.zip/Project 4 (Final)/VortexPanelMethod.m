function [gammaVec,Vi,Cpi,theta,S,x,y] = VortexPanelMethod(m,alpha,V_inf,XB,YB)
%UNTITLED3 Summary of this function goes here
%   Parent program. Every sub-procedure called from here. Returns pressure
%   distribution using vortex panel method, with N vortex panels

[x,y,theta,S] = panelCalcs(XB,YB);

b = zeros(m+1,1);
c = zeros(m,1);
Cn1 = zeros(m,m);
Cn2 = zeros(m,m);
Ct1 = zeros(m,m);
Ct2 = zeros(m,m);
coeff = zeros(m+1,m+1);
for i = 1:m
    b(i) = sin(theta(i) - alpha);
    c(i) = cos(theta(i) - alpha);
    for j = 1:m
        if i == j
            Cn1(i,j) = -1;
            Cn2(i,j) = 1;
            Ct1(i,j) = 0.5*pi;
            Ct2(i,j) = 0.5*pi;
        else
            A = -((x(i)-XB(j))*cos(theta(j)))-(((y(i)-YB(j))*sin(theta(j))));
            B = ((x(i)-XB(j))^2)+(y(i)-YB(j))^2;
            C = sin(theta(i)-theta(j));
            D = cos(theta(i)-theta(j));
            E = (x(i)-XB(j))*sin(theta(j))-(y(i)-YB(j))*cos(theta(j));
            F = log(1+(((S(j)^2)+(2*A*S(j)))/(B)));
            G = atan2((E*S(j)),(B + A*S(j)));
            P = (x(i)-XB(j))*sin(theta(i)-2*theta(j))+ (y(i)-YB(j))*cos(theta(i)-2*theta(j));
            Q = (x(i)-XB(j))*cos(theta(i)-2*theta(j))- (y(i)-YB(j))*sin(theta(i)-2*theta(j));
            Cn2(i,j) = D + (0.5*Q*F/S(j)) - (A*C+D*E)*(G/S(j)); 
            Cn1(i,j) = 0.5*D*F+C*G-Cn2(i,j);
            Ct2(i,j) = C + (0.5*P*F/S(j)) + (((A*D)-(C*E))*G/S(j));
            Ct1(i,j) = 0.5*C*F - D*G - Ct2(i,j);
        end
    end
end

for i = 1:m
    coeff(i,1) = Cn1(i,1);
    coeff(i,m+1) = Cn2(i,m);
    for j = 2:m
        coeff(i,j) = Cn1(i,j)+Cn2(i,j-1);
    end
end
coeff(m+1,1) = 1;
coeff(m+1,m+1) = 1;
for j = 2:m
    coeff(m+1,j) = 0;
end
b(m+1) = 0;

gammaNoDim = coeff\b;
gammaVec = gammaNoDim*2*pi*V_inf;

%Have just calculated the gamma's for endpoints of each panel.
%Now want to find velocities parallel to boundaries?

coefft = zeros(m,m+1);
for i = 1:m
   coefft(i,1) = Ct1(i,1);
   for j = 2:m
      coefft(i,j) = Ct1(i,j)+Ct2(i,j-1); 
   end
   coefft(i,m+1) = Ct2(i,m);
end
Vi = coefft*(gammaNoDim) + c;
Cpi = 1 - Vi.^2;

end

