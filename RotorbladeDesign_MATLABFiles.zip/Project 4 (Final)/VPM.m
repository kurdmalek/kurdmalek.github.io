function [CP,Sj,x,y,vt,theta] = VPM(X,Y,alpha,U)

%VPM delivers the pressure distribution surrounding an inputted geometric body, using the vortex panel method. 
N = length(X)-1;
g = zeros(1,N); %gamma vector
b = zeros(N+1,1);
c = zeros(N,1);
C1n = zeros(N,N);
C2n = zeros(N,N);
C1t = zeros(N,N);
C2t = zeros(N,N);
An = zeros(N+1,N+1);
At = zeros(N,N+1);
x = zeros(1,N);
y = zeros(1,N);
Sj = zeros(1,N);
theta = zeros(1,N);
rho = 0.016; %air density @ sea-level

for i = 1:N
    x(i) = 0.5*(X(i+1)+X(i)); %defining control points on panel i
    y(i) = 0.5*(Y(i+1)+Y(i));
    theta(i)=atan2((Y(i+1)-Y(i)),(X(i+1)-X(i)));
    Sj(i) = sqrt((X(i+1)-X(i))^2+(Y(i+1)-Y(i))^2); %panel length
end

for i = 1:N
    b(i) = sin(theta(i) - alpha);
    c(i) = cos(theta(i) - alpha);
    for j = 1:N
        if i == j
            C1n(i,j)=-1;
            C2n(i,j)=1;
            C1t(i,j)=0.5*pi;
            C2t(i,j)=0.5*pi;
        else
            %Defining coefficients for the normal-velocity matrix, A-n.
            A = -((x(i)-X(j))*cos(theta(j))) - ((y(i)-Y(j))*sin(theta(j)));
            B = ((x(i)-X(j))^2) + (y(i)-Y(j))^2;
            C = sin(theta(i)-theta(j));
            D = cos(theta(i)-theta(j));
            E = (x(i)-X(j))*sin(theta(j)) - (y(i)-Y(j))*cos(theta(j));
            F = log(1+((Sj(j)^2)+2*A*Sj(j))/B);
            G = atan2((E*Sj(j)),(B + A*Sj(j)));
            P = (x(i)-X(j))*sin(theta(i)-2*theta(j)) + (y(i)-Y(j))*cos(theta(i)-2*theta(j));
            Q = (x(i)-X(j))*cos(theta(i)-2*theta(j)) - (y(i)-Y(j))*sin(theta(i)-2*theta(j));
            C2n(i,j) = D + (0.5*Q*F/Sj(j)) - (A*C+D*E)*(G/Sj(j));
            C1n(i,j) = 0.5*D*F + C*G - C2n(i,j);
            %Defining coefficients for the tangential velocity matrix, A-t.
            C2t(i,j) = C+(0.5*P*F/Sj(j))+((A*D)-(C*E))*G/Sj(j);       
            C1t(i,j) = 0.5*C*F-(D*G)-C2t(i,j);        
        end
    end
end


%Building A-n matrix

for i = 1:N
    An(i,1)=C1n(i,1);
    An(i,N+1)=C2n(i,N);
    for j = 2:N
        An(i,j)=C1n(i,j)+C2n(i,j-1);
    end
end
An(N+1,1)= 1;
An(N+1,N+1)=1;
for j = 2:N
    An(N+1,j)=0;
end
b(N+1) = 0;

g = An\b;

%Building A-t matrix

 for i = 1:N
     At(i,1)=C1t(i,1);
     for j = 2:N
         At(i,j)=C1t(i,j)+C2t(i,j-1);
     end
     At(i,N+1)=C2t(i,N);
 end


vt = (At*g) + c;
CP = 1-vt.^2;

end